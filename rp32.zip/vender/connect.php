<?php 
    $connect = mysqlli_connect('localhost', 'root', 'root', 'registration');